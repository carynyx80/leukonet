// src/detectors/lookalike.ts
var HOMOGLYPHS = { "0": "o", "1": "l", "3": "e", "4": "a", "5": "s", "7": "t", "8": "b", "9": "g", i: "l" };
function normalize(name) {
  return name.toLowerCase().replace(/rn/g, "m").replace(/vv/g, "w").split("").map((c) => HOMOGLYPHS[c] ?? c).join("").replace(/[-_.]/g, "");
}
function editDistance(a, b) {
  const d = Array.from({ length: a.length + 1 }, (_, i) => [i, ...Array(b.length).fill(0)]);
  for (let j = 1; j <= b.length; j++) d[0][j] = j;
  for (let i = 1; i <= a.length; i++) {
    for (let j = 1; j <= b.length; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + cost);
      if (i > 1 && j > 1 && a[i - 1] === b[j - 2] && a[i - 2] === b[j - 1]) d[i][j] = Math.min(d[i][j], d[i - 2][j - 2] + 1);
    }
  }
  return d[a.length][b.length];
}
function split(accountId) {
  const i = accountId.indexOf(".");
  return i < 0 ? [accountId, ""] : [accountId.slice(0, i), accountId.slice(i + 1)];
}
function imitates(candidate, protectedNames, maxDistance) {
  if (protectedNames.includes(candidate)) return null;
  const [label, parent] = split(candidate);
  for (const p of protectedNames) {
    const [pLabel, pParent] = split(p);
    if (parent !== pParent) continue;
    if (pLabel.length < 4) continue;
    if (label === pLabel) continue;
    const nCand = normalize(label);
    const nProt = normalize(pLabel);
    const dist = editDistance(nCand, nProt);
    if (nCand === nProt || dist > 0 && dist <= maxDistance && dist < pLabel.length / 3) return p;
  }
  return null;
}

// src/protected.ts
var MAINNET_PROTECTED = [
  "wrap.near",
  "ref-finance.near",
  "v2.ref-finance.near",
  "app.ref-finance.near",
  "rhea.near",
  "intents.near",
  "meta-pool.near",
  "linear-protocol.near",
  "burrow.near",
  "token.sweat",
  "sweat_welcome.near",
  "usdt.tether-token.near",
  "aurora",
  "relay.aurora",
  "hot.tg",
  "game.hot.tg",
  "herewallet.near",
  "mynearwallet.near",
  "meteorwallet.near",
  "mintbase1.near",
  "paras.near",
  "sputnik-dao.near",
  "social.near",
  "nearkat.near",
  "lockup.near",
  "poolv1.near",
  "bitte.near",
  "near"
];

// extension/src/shared.ts
var DEFAULTS = {
  registry: "registry.leukonet-mw43jm6i.testnet",
  rpcUrl: "https://rpc.testnet.fastnear.com",
  explorer: "https://testnet.nearblocks.io",
  site: "https://leukonet.vercel.app"
};
var cache = /* @__PURE__ */ new Map();
async function settings() {
  try {
    const s = await chrome.storage.sync.get(DEFAULTS);
    return { ...DEFAULTS, ...s };
  } catch {
    return DEFAULTS;
  }
}
async function isSafe(id, s) {
  const res = await fetch(s.rpcUrl, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      jsonrpc: "2.0",
      id: "guard",
      method: "query",
      params: { request_type: "call_function", finality: "optimistic", account_id: s.registry, method_name: "is_safe", args_base64: btoa(JSON.stringify({ account_id: id })) }
    })
  });
  const body = await res.json();
  if (body.error || !body.result?.result) throw new Error("registry unavailable");
  return JSON.parse(new TextDecoder().decode(new Uint8Array(body.result.result)));
}
async function check(id) {
  id = id.trim().toLowerCase();
  const hit = cache.get(id);
  if (hit && Date.now() - hit.at < 6e4) return hit.v;
  const s = await settings();
  const fake = id.endsWith(".near") ? imitates(id, MAINNET_PROTECTED, 2) : null;
  let v;
  try {
    const c = await isSafe(id, s);
    const level = !c.safe ? "scam" : c.pending_reports.length ? "pending" : fake ? "impostor" : "clean";
    v = { account_id: id, level, risk: c.risk, categories: c.categories, report_ids: c.safe ? c.pending_reports : c.report_ids, imitates: fake ?? void 0 };
  } catch (e) {
    v = { account_id: id, level: fake ? "impostor" : "unknown", risk: 0, categories: [], report_ids: [], imitates: fake ?? void 0, error: String(e?.message ?? e) };
  }
  cache.set(id, { at: Date.now(), v });
  return v;
}
function sentence(v) {
  const human = (c) => c.replace(/([a-z])([A-Z])/g, "$1 $2").toLowerCase();
  switch (v.level) {
    case "scam":
      return `Do not pay. Confirmed ${v.categories.map(human).join(", ")} (risk ${v.risk}/100, report #${v.report_ids.join(", #")}).`;
    case "pending":
      return `Careful: report #${v.report_ids.join(", #")} against this account is being voted on right now.`;
    case "impostor":
      return `Looks like an impostor of ${v.imitates}. Check the exact name before paying.`;
    case "clean":
      return "No confirmed threats. That means not caught yet, not guaranteed safe.";
    default:
      return "Couldn't reach the registry. Try again in a moment.";
  }
}

// extension/src/popup.ts
var $ = (id) => document.getElementById(id);
var TITLES = { scam: "Do not pay", pending: "Report open", impostor: "Possible impostor", clean: "No confirmed threats", unknown: "Registry unreachable" };
settings().then((s) => {
  $("reg").textContent = s.registry.replace(/^registry\./, "");
  $("site").href = s.site;
});
$("f").addEventListener("submit", async (e) => {
  e.preventDefault();
  const id = $("q").value.trim().toLowerCase();
  if (!id) return;
  $("title").textContent = "Checking\u2026";
  $("msg").textContent = id;
  $("out").className = "out";
  $("out").hidden = false;
  const v = await check(id);
  $("out").className = `out ${v.level}`;
  $("title").textContent = TITLES[v.level];
  $("msg").textContent = `${v.account_id}: ${sentence(v)}`;
});
$("scan").addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) return;
  let marked = 0;
  try {
    marked = await chrome.tabs.sendMessage(tab.id, { type: "scan" });
  } catch {
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] });
    await new Promise((r) => setTimeout(r, 1500));
    marked = await chrome.tabs.sendMessage(tab.id, { type: "scan" }).catch(() => 0);
  }
  $("scanned").hidden = false;
  $("scanned").textContent = marked ? `${marked} risky account${marked === 1 ? "" : "s"} marked` : "Nothing risky on this page";
});
